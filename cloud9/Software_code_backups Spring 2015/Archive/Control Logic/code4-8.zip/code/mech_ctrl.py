import Adafruit_BBIO.GPIO as GPIO

def setup_GPIO():
    try:
        True
        return 'True'
    except Exception:
        return 'False'
# GPIO.setup("P8_10", GPIO.OUT)
# setup all GPIO pins as necessary

" Not sure if this function is usefull but definetly"
"nice to have"
def cleanup_GPIO():
    try:
        GPIO.cleanup()
        return 'True'
    except Exception:
        return 'False'
    
"This function turns a solenoid ON or OFF"
"This assumes all the GPIO are set up as a part of the init routine"    
def solenoid(port_id,status):
    try:    
        if status=='ON':
            GPIO.output(port_id,GPIO.HIGH)
            return 'True'
        if status=='OFF':
            GPIO.output(port_id,GPIO.LOW)
            return 'True'
        return 'False' #If the status is neither ON/OFF operation Falseed
    except Exception:
        return 'False'
    
"This function turns a Pump ON or OFF"
"This assumes all the GPIO are set up as a part of the init routine"    
def pump(port_id,status):
    try:    
        if status=='ON':
            GPIO.output(port_id,GPIO.HIGH)
            return 'True'
        if status=='OFF':
            GPIO.output(port_id,GPIO.LOW)
            return 'True'
        return 'False' #If the status is neither ON/OFF operation Falseed
    except Exception:
        return 'False'        
        
      
    

