import Queue
import threading
import time
import datetime
import serial
import json
import zmq
import mech_ctrl
import global_var

if __debug__:
    pass    
else:
    import Adafruit_BBIO.UART as UART
    import Adafruit_BBIO.GPIO as GPIO
    import smbus
    import numpy as np
    


#sensor_hash_table={} #create sersor hash table
BB1_msg_q=Queue.Queue() #Create global queue

"Enqueue Function"
def Message_Queue(obj):
    BB1_msg_q.put(obj)
    return
    
#------------------------------------------------------------------------------------------#

"""Sensor Object structures"""

class Generic_Sensor_Struct():
    def __init__(self, timestamp, value,component):
        self.value = value
        self.timestamp = timestamp
        self.component=component

class RH_Temp_Struct():
    def __init__(self, timestamp, RH,Temp,component):
        self.RH = RH
        self.Temp = Temp
        self.timestamp = timestamp
        self.component=component
        
class Flow_Meter_Struct():
    def __init__(self,timestamp,x,y,z,component):
        self.x=x
        self.y=y
        self.z=z
        self.timestamp=timestamp
        self.component=component
        
class Camera_Struct():
    def __init__(self,timestamp,arr):
        self.arr=arr
        self.timestamp=timestamp


#------------------------------------------------------------------------------------------#
             
""" Thread data object classes """

class PWM_Data():
    def __init__(self, duty_cycle, freq, port,component):
        self.duty_cycle = duty_cycle
        self.freq = freq
        self.port = port
        self.component = component


"""ADC Data Class"""
class ADC_Data():
   def __init__(self, reading, port,component):
       self.reading = reading
       self.port = port
       self.component = component


class I2C_Data():
    def __init__(self, reading, address, port,component):
        self.reading = reading
        self.address = address
        self.port = port
        self.component = component

class RH_Temp_Data():
    def __init__(self, reading_RH, reading_Temp, address, port,component):
        self.reading_RH = reading_RH
        self.reading_Temp = reading_Temp
        self.address = address
        self.port = port
        self.component = component

class UART_Data():
    def __init__(self, reading, port_RX, port_TX,component):
        self.reading = reading
        self.port_RX = port_RX
        self.port_TX = port_TX
        self.component = component
#------------------------------------------------------------------------------------------#
"Messaging Queue for Sensor Data as server"
#Initializing server as PAIR
def init_messages():
    port="5555"
    context=zmq.Context();
    global socket_control
    socket_control=context.socket(zmq.PAIR);
    socket_control.bind("tcp://*:%s" % port);
    return

#Send message to client
def send_to_client(value):
    value=json.dumps(value);
    socket_control.send(value);
    return

#Thread which constantly recives messages from the client and
#queue them to the QMH
class Server_receive(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        while True:
            msg=socket_control.recv();
            msg=json.loads(msg)
            Message_Queue(msg); #Enqueue Message

#------------------------------------------------------------------------------------------#
#------------------------------------------------------------------------------------------#
"Message Queue to update HSST Table"
def init_HSST_messages():
    port="5555"
    context_HSST=zmq.Context();
    global socket_HSST
    socket_HSST=context_HSST.socket(zmq.PAIR);
    socket_HSST.bind("tcp://*:%s" % port);
    return
#Send message to client
def send_HSST_message(value):
    value=json.dumps(value);
    socket_HSST.send(value);
    return
#Thread which constantly recives messages from the client and
#queue them to the QMH
class rcv_HSST_message(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)

    def run(self):
        while True:
            msg=socket_HSST.recv();
            msg=json.loads(msg)
            Message_Queue(msg); #Enqueue Message

#------------------------------------------------------------------------------------------#


#Start Main loop
"Build Case Structure i.e C switch statement equivalent"
def relay_control():
    port_id=consumer.port_id;
    status=consumer.status;
    mech_ctrl.GPIO_set(port_id,status)
    return
def HSST_update():
    global_var.hsst_hash[consumer.key]=consumer.value;
    return

class HSST_element():
    def __init__(self, case, key, value):
        self.case=case
        self.key=key
        self.value=value
 
    
    

def main():
    global_var.init_sensor_hash_table()#Initialize sensor hash table
    global_var.init_hash_table()#Initialize hsst hash table
    init_sensor_threads()#Launch all threads
    #Message Queue
    BB1_msg_q=Queue.Queue() #Create global queue
    init_messages();
    message_control_thread=server_receive(); # launch Receive thread
    #Setup GPIO
    mech_ctrl.setup_GPIO_BB1();
    #Initialize Events
    
    
    
    while True:
        consumer=BB1_msq_q.get()
        #Switch implementation
        try:
            switch[consumer.case]();
        except NameError:
            pass
            #default case
        

        
        
