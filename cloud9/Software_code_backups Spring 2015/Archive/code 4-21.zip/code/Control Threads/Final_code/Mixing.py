#Mixing Process
import threading
import global_var
#implement dual locking mechanism only single event has been coded in
P3_port="P8_39"    #NPK1 pump
P4_port="P8_41"    #NPK2 pump
P2_port="P8_37"    #Condensate Pump
P8_port="P8_45"   #Pre-Filter Pump
P5_port="P8_43"    #ph Pump
class Mixing_Process(threading.Thread):
    def __init__(watering_event,global_event):
        threading.Thread.__init__(self)
        self.watering_event=watering_event
        self.global_event=global_event
        
    def run(self):
        pass
        while True:
            self.global_event.wait() # Global stop when flag is cleared
            S112_value=getvalue() # T9 S112 level sensor        
            global_var.insert_sensor_hash("LL_2",S112_value)
            S105_value=getvalue()
            global_var.insert_sensor_hash("LL_1",S105_value)
            S113_value=getvalue()
            global_var.insert_sensor_hash("LL_3",S113_value)
            HSST_N22=global_var.hsst_hash("N22")
            HSST_N21=global_var.hsst_hash("N21")
            while ((S112_value>HSST_N22) and (S105+S113<HSST_N21)):
                self.watering_event.clear() # Stop watering function
                while not global_var.watering_paused: #Wait till the watering function is stopped
                    time.sleep(1)                
                leachate_dump()
                condensation_dump()
                NTR_conditioning()
                pH_Conditioning()
                gloabl_var.watering_paused=False;
                self.watering_event.set() #Resume watering function
                #Recollect all data and start loop again
                Sll2_value=getvalue() # T9 S112 level sensor
                global_var.insert_sensor_hash("LL_2",S112_value)
                S105_value=getvalue()
                global_var.insert_sensor_hash("LL_1",S105_value)
                S113_value=getvalue()
                global_var.insert_sensor_hash("LL_3",S113_value)
                HSST_N22=global_var.hsst_hash("N22")
                HSST_N21=global_var.hsst_hash("N21")
                time.sleep(unknown) #polling rate
            time.sleep(unknown)
                


"Condensation Dump Function"
#Incorporate control logic V6
def Condensation_Dump():
    HSST_M26=global_var.hsst_hash("M26");
    S106_value=getlevelvalue()
    global_var.insert_sensor_hash("LL_4",S106_value)
    
    if S106_value>HSST_M26:
        while S106_level > HSST_M26:
            mech_ctrl.pump(P2_port,GPIO.HIGH) #Activate Condensation pump P2
            time.sleep(undefined)
            S106_value=getlevelvalue()
            global_var.insert_sensor_hash("LL_4",S106_value)
        mech_ctrl.pump(P2_port,GPIO.LOW) #Deactivate Condensation pump P2
        return
    else:
        return
    

"Nutrient Conditioning Function"
def NTR_Conditioning():
    EC_S101_value=getecvalue()
    global_var.insert_sensor_hash("EC_1",EC_S101_value)
    HSST_K12=global_var.hsst_hash("K12")
    HSST_J12=global_var.hsst_hash("J12")
    HSST_I12=global_var.hsst_hash("I12")
    while EC_S101_value < HSST_K12:
        mech_ctrl.pump(P3_port,GPIO.HIGH) #Activate NTR1 P3
        mech_ctrl.pump(P4_port,GPIO.HIGH) #Activate NTR2 P4
        time.sleep(HSST_J12)
        mech_ctrl.pump(P3_port,GPIO.LOW) #Deactivate NTR1 P3
        mech_ctrl.pump(P4_port,GPIO.LOW) #Deactivate NTR2 P4
        time.sleep(HSST_I12)
        EC_S101_value=getecvalue()
        global_var.insert_sensor_hash("EC_1",EC_S101_value)
    return

"pH Conditioning Functions"

def pH_Conditioning():
    PH_S109_value=getphvalue()
    global_var.insert_sensor_hash("LL_7",PH_S109_value)
    HSST_L16=global_var.hsst_hash("L16")
    HSST_J16=global_var.hsst_hash("J16")
    HSST_I16=global_var.hsst_hash("I16")
    while PH_S109_Value > HSST_L16:
        mech_ctrl.pump(P5_port,GPIO.HIGH) # Activate PH Pump P5
        time.sleep(HSST_J16) #Actuation time
        mech_ctrl.pump(P5_port,GPIO.LOW) # Activate PH Pump P5
        time.sleep(HSST_I16) #Settling time
        PH_S109_value=getphvalue()#Read again and loop over
        global_var.insert_sensor_hash("LL_7",PH_S109_value)
    return
        

"Leachate Dump Function"
def leachate_dump():    
    S112_value=getvalue();
    global_var.insert_sensor_hash("LL_2",S112_value)
    S105_value=getvalue();
    global_var.insert_sensor_hash("LL_1",S105_value)
    S113_value=getvalue();
    global_var.insert_sensor_hash("LL_3",S113_value)
    HSST_M22=global_var.hsst_hash("M22")
    HSST_N21=global_var.hsst_hash("N21")
    mech_ctrl.pump(P8_port,GPIO.HIGH) # Activate Pre-Filter Pump P8
    while not ((S112_value < HSST_M22) or ((S105+S113) > HSST_N21)):        
        S112_value=getvalue();
        global_var.insert_sensor_hash("LL_2",S112_value)
        S105_value=getvalue();
        global_var.insert_sensor_hash("LL_1",S105_value)
        S113_value=getvalue();
        global_var.insert_sensor_hash("LL_3",S113_value)
    mech_ctrl.pump(P8_port,GPIO.LOW) # deactivate Pre-Filter Pump P8
        
        
    
    
    

    
        
    
        
