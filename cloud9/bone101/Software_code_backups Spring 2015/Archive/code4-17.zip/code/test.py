if (True):
    print 'pass'
if (False):
    print 'false'

